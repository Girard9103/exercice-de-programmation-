﻿using System;

public class Application
{
	public void fonctionPrincipale ()
	{
		//DEBUT de votre programme
		Date d = new Date(24,3,1954);
		d.afficher();
		Date d1 = new Date();
		d1.afficher();
		Date d2 = new Date();
		d2.afficher();
		//FIN de votre programme
	}

	//DECLAREZ VOS FONCTIONS EN DESSOUS DE CETTE LIGNE

	/* EXEMPLES DE PROCEDURES ET FONCTIONS :
	
		void uneProcedure(int param1, int param2)
		{
			Console.WriteLine(param1+param2);
		{
		
		int uneFonction(int param1, int param2)
		{
			int resultat = 0;
			resultat = param1 + param2;
			return resultat;
		}
		
		
		*/

	//NE PAS TOUCHER LE CODE EN DESSOUS DE CETTE LIGNE
}


