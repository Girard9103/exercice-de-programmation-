class Date
{
    public int jour = 0;
    public int mois = 0;
    public int annee = 0;
}