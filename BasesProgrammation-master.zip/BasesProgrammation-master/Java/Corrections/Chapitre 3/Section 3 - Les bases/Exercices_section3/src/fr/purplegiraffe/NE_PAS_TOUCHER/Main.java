package fr.purplegiraffe.NE_PAS_TOUCHER;

import fr.purplegiraffe.Application;

public class Main {

    public static void main(String[] args) {
        Application app = new Application();
        app.fonctionPrincipale();
    }
}
