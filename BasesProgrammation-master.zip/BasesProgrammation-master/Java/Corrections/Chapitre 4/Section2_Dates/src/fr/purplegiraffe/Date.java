package fr.purplegiraffe;

public class Date {
    public int jour;
    public int mois;
    public int annee;
}
