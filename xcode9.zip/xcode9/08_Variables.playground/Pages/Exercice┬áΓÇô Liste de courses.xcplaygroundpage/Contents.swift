/*:
 ## Exercice – Créer une liste de courses

 Les constantes ci-dessous représentent des articles pouvant figurer sur une liste de courses :
*/
let eggs = "Œufs"
let milk = "Lait"
let cheese = "Fromage"
let bread = "Pain"
let rice = "Riz"
let newLine = "\n"
//: - callout(Exercise):
//:(Exercice) :\
//:Créez une variable de chaîne dont la valeur initiale est `""`. Ajoutez les valeurs constantes à la liste une par une. Ajoutez une `newLine` entre chaque article. Souvenez-vous que vous pouvez lier deux chaînes en utilisant l’opérateur `+`.






//: [Précédent](@previous)  |  page 12 sur 13  |  [Suivant : Exercice – 501](@next)
