import UIKit

/// Contient un champ de texte qui permet à l’utilisateur de saisir une question 
class AskCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!

}
