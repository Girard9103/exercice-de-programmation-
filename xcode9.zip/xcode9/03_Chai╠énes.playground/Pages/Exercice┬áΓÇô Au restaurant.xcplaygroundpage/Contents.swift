/*:
 ## Exercice – Au restaurant
 */
let customerOrderOne = "poisson"
let customerOrderTwo = "risotto"
let customerOrderThree = "soupe"

let serverResponseToTableOne = "Je récapitule la commande : poisson, risotto et soupe. C’est tout ?"

let tableOneResponse = "Oui, merci !"

/*:
 ### Plus tard le même jour :
 
 
 Trois autres clients entrent et passent leur commande :
 */

let customerOrderFour = "돌솥비빔밥"
let customerOrderFive = "Pasztecik szczeciński"
let customerOrderSix = "小笼包"

/*:
 Le serveur parle ces trois langues et confirme facilement au groupe les commandes.
 
- callout(Exercise):
(Exercice) :\
Assurez-vous que le serveur confirme correctement les commandes *sans* les copier-coller, ni les ressaisir.
 */
let serverResponseToTableTwo = "Je récapitule la commande : <Saisissez la commande ici>"

let tableTwoResponse = "Perfect, merci bien."



//:
//:[Précédent](@previous)  |  page 14 sur 16  |  [Suivant : Exercice – On est les meilleurs !](@next)
