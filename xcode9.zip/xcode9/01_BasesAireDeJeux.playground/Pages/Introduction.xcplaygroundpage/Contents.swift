//: ## Les bases de l’aire de jeux
//: Bienvenue dans votre première aire de jeux ! Dans ce cours, vous allez utiliser les aires de jeux pour apprendre les bases de la programmation. Commençons par visiter les lieux et écrire quelques lignes de code.
//:
//: Avant de commencer, voyez-vous les points animés ci-dessous ?
//: Si ce n’est pas le cas, sélectionnez Editor > Show Rendered Markup (Éditeur > Afficher le rendu des annotations) dans la barre des menus.
//:
//: ![points animés](swiftloading.gif)
//:
//: Si vous voyez les points animés, vous êtes prêt à commencer.
//:
//:page 1 sur 7  |  [Suivant : Qu’est-ce qu’une aire de jeux ?](@next)
