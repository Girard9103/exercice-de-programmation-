/*:
 ## Exercice – Définir des enum
 
 Entraînez-vous à définir vos propres enum. Pensez à respecter les règles de nommage des enum et de leurs cas. 
 
 - callout(Exercise):
(Exercice) :\
Définissez une enum avec les points cardinaux : nord, est, sud et ouest.
*/





//: - callout(Exercise):
//:(Exercice) :\
//:Définissez une enum avec des pièces de puzzle : angle, bord et milieu.




//: - callout(Exercise):
//:(Exercice) :\
//:Définissez une enum avec les modes de lecture d’une app de musique : lire, répéter, aléatoire.
 
 
 



//: [Précédent](@previous)  |  page 17 sur 21  |  [Suivant : Exercice – Compter les poussins](@next)
