/*:
 ## Exercice – Mise en pratique des instructions if
 
 Entraînez-vous à utiliser des instructions if en reformulant les commentaires suivants sous forme de code.
*/
let a = 20
let b = 30
let c = 20

// Si a est égal à c, écrire « a et c sont identiques »



// Si a est inférieur à b, écrire « b est supérieur à a »



// Si b est supérieur à a, écrire « a ne peut pas l’emporter face à b »



// Si a est inférieur ou égal à c, écrire « a est devancé par c, ou à égalité avec »



//: - callout(Exercise):
//:(Exercice) :\
//:Rédigez votre code sous chacun des commentaires et suivez les instructions. (Pour ne pas confondre les opérateurs de supériorité et d’infériorité, pensez à la bouche grande ouverte.)
//:
//: [Précédent](@previous)  |  page 11 sur 13  |  [Suivant : Exercice – Mise en pratique des instructions else](@next)
