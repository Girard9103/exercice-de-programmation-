/*:
 ## BoogieBot
 
 Dans cette aire de jeux, vous allez faire connaissance avec BoogieBot, un robot dansant.
 
 Vous utiliserez vos connaissances des fonctions pour faire danser BoogieBot en appelant des fonctions existantes. Vous définirez ensuite vos propres fonctions pour créer des chorégraphies.
 
 Enfin, vous ajouterez un titre, signerez votre travail et l’enregistrerez en tant qu’image animée, comme celle que vous voyez ici :
 
 ![](BoogieBotDemo.gif)
 
 Mais commençons par configurer votre aire de jeux pour faire danser le robot.
 
 page 1 sur 13  |  [Suivant : Vues en temps réel](@next)
*/
