

private let swiftBird = " |                            -                   \n |                            .ds-                \n |              :.             `mMh-              \n |         -+.   /y:            :MMMy`            \n |         `sd/` .dd/           hMMMN:           \n |            -dNy- +MNs.        +MMMMM/          \n |              +NMmo:hMMh/`     /MMMMMM.         \n |              `oNMMdyNMMNy:   oMMMMMMh         \n |                 `oNMMMMMMMMNs:mMMMMMMM         \n |                  `oNMMMMMMMMMMMMMMMMM`        \n |    `                +mMMMMMMMMMMMMMMN         \n |      +y/.              :dMMMMMMMMMMMMy         \n |       .hMNhs+/:----:/oydMMMMMMMMMMMMMMh`       \n |         -yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMh       \n |          `+hMMMMMMMMMMMMMMMMMMMMdhhdNMM/      \n |              `:oymNMMMMMMMMMNho-      :hs      \n |                    `.-:::-.`            `      \n |"


private func calculatedAnswer() -> Int {
    print("Hé, ce truc de programmation peut être intéressant pour avancer !\n\n")
    print(swiftBird)
    print("\n(en un coup)")
    return 42
}

public let theAnswer = calculatedAnswer()
